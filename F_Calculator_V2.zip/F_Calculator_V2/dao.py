

# Create table and save data to database
def save_data(n1, n2, result):
    print("---DAO Layer: Saving Result---")
    pass

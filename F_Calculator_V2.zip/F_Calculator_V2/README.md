F-Calculator
===============
Simple RESTful calculator web application using Flask and jQuery

### Installation ###

  1. From inside the "F-Calculator" 
     run "pip install -r requirements.txt"   (python -m pip install psycopg2)
  2. set FLASK_APP = app.py
  2. For running, > python app.py   # Deploying flask project in local system
  3. Open a browser and go to http://127.0.0.1:5000
